import ch.ethz.inf.pm.sample.abstractdomain.*;
import project.AVPDomain;

public class NumericalAnalysis extends AVPDomain<TopDomain, NumericalAnalysis> {

  public NumericalAnalysis assign(Identifier variable, Expression expr) {
      if(expr instanceof Constant)
          System.out.println("I'm assigning a constant! "+((Constant) expr).constant());
      if(expr instanceof VariableIdentifier) {
          System.out.println("I'm assigning a variable! "+((VariableIdentifier) expr).getName());
          System.out.println("Its old value is "+this.get((VariableIdentifier) expr));
      }
      if(expr instanceof BinaryArithmeticExpression)
          System.out.println("I'm assigning an arithmetic expression! "+((BinaryArithmeticExpression) expr).left()+((BinaryArithmeticExpression) expr).op()+((BinaryArithmeticExpression) expr).right());
      //Possible operators are +, -, *, /, %
      return this;
  }
  public NumericalAnalysis assume(Expression expr) {
      if(expr instanceof BinaryArithmeticExpression)
          System.out.println("I'm evaluating a boolean comparison! "+((BinaryArithmeticExpression) expr).left()+((BinaryArithmeticExpression) expr).op()+((BinaryArithmeticExpression) expr).right());
      if(expr instanceof NegatedBooleanExpression)
          System.out.println("I'm evaluating a boolean negation! "+((NegatedBooleanExpression) expr).thisExpr());
      return this;
  }

  //Create a new instance representing a state of the domain
  public NumericalAnalysis factory() {
      return this;
  }

  //Return the bottom value
  public TopDomain bottomValue() {
      return new TopDomain();
  }

}
