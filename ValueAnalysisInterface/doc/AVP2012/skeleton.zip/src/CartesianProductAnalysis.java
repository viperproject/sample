import project.ReducedAVPDomain;


public class CartesianProductAnalysis extends ReducedAVPDomain<NumericalAnalysis, TopDomain, NumericalAnalysis, TopDomain, CartesianProductAnalysis>{
    public CartesianProductAnalysis() {
        super(new NumericalAnalysis(), new NumericalAnalysis());
    }
    public CartesianProductAnalysis reduce() {
        return this;
    }
    public CartesianProductAnalysis factory() {
        return new CartesianProductAnalysis();
    }
}
