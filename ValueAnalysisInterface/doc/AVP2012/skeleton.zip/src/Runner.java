import project.*;

public class Runner {

	public static void main(String[] args) {
		Main.run(
                "C:\\Users\\Pietro\\Documents\\Lavoro\\Teaching\\AVP2012\\project\\CaseStudies.scala",  //filepath
                "example1", //method to analyze
                //new NumericalAnalysis()
                new CartesianProductAnalysis() //instance of the analysis
        );
	}
}
