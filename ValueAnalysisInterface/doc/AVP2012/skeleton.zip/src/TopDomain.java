import ch.ethz.inf.pm.sample.abstractdomain.Lattice;

//This class represents the abstraction of values
//You have to implement all methods defined by Lattice (common lattice operators, widening, and some Java specific methods like equals and toString
public class TopDomain implements Lattice<TopDomain> {

    public boolean lessEqual(TopDomain a) {
    	return true;
    }
    public TopDomain widening(TopDomain a, TopDomain b) {
    	return this;
    }
    public TopDomain glb(TopDomain a, TopDomain b){
    	return this;
    }
    public TopDomain lub(TopDomain a, TopDomain b){
    	return this;
    }
    public TopDomain bottom(){
    	return this;
    }
    public TopDomain top(){
    	return this;
    }
    public TopDomain factory(){
    	return this;
    }

    public Object clone() {
    	return this;
    }
    public boolean equals(Object a) {
    	return a instanceof TopDomain;
    }
    public int hashCode() {
    	return 1;
    }
    public String toString() {
    	return "T";
    }
}
